﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Project_Pexitics.Migrations
{
    public partial class x2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tbl_assign",
                columns: table => new
                {
                    ProjectID = table.Column<int>(nullable: false),
                    TraineeEmail = table.Column<string>(nullable: false),
                    AssignedDate = table.Column<DateTime>(nullable: false, computedColumnSql: "getdate()"),
                    ProjectStatus = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_assign", x => new { x.ProjectID, x.TraineeEmail });
                });

            migrationBuilder.CreateTable(
                name: "tbl_NewTrainee",
                columns: table => new
                {
                    Name = table.Column<string>(maxLength: 100, nullable: false),
                    Email = table.Column<string>(nullable: false),
                    password = table.Column<string>(maxLength: 10, nullable: false),
                    City = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_NewTrainee", x => x.Email);
                });

            migrationBuilder.CreateTable(
                name: "tbl_Projects",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(maxLength: 100, nullable: false),
                    Description = table.Column<string>(maxLength: 100, nullable: false),
                    Technology = table.Column<string>(nullable: false),
                    AssignDate = table.Column<DateTime>(nullable: false,defaultValueSql:"getdate()"),
                    AddedByEmail = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Projects", x => x.ID);
                    table.ForeignKey(
                        name: "FK_tbl_Projects_tbl_NewTrainee_AddedByEmail",
                        column: x => x.AddedByEmail,
                        principalTable: "tbl_NewTrainee",
                        principalColumn: "Email",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbl_Trainee",
                columns: table => new
                {
                    FirstName = table.Column<string>(maxLength: 100, nullable: false),
                    LastName = table.Column<string>(maxLength: 100, nullable: false),
                    Email = table.Column<string>(nullable: false),
                    Password = table.Column<string>(maxLength: 10, nullable: false),
                    Qualification = table.Column<string>(maxLength: 100, nullable: false),
                    AddedByEmail = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Trainee", x => x.Email);
                    table.ForeignKey(
                        name: "FK_tbl_Trainee_tbl_NewTrainee_AddedByEmail",
                        column: x => x.AddedByEmail,
                        principalTable: "tbl_NewTrainee",
                        principalColumn: "Email",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tbl_Projects_AddedByEmail",
                table: "tbl_Projects",
                column: "AddedByEmail");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_Trainee_AddedByEmail",
                table: "tbl_Trainee",
                column: "AddedByEmail");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbl_assign");

            migrationBuilder.DropTable(
                name: "tbl_Projects");

            migrationBuilder.DropTable(
                name: "tbl_Trainee");

            migrationBuilder.DropTable(
                name: "tbl_NewTrainee");
        }
    }
}
