﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Pexitics.Filters
{
    public class AuthFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.HttpContext.Session.GetString("TrEmail") == null && (context.RouteData.Values["action"].ToString()!="Login" 
                && context.RouteData.Values["action"].ToString() != "AddTrainer"))
            {
                context.Result = new RedirectResult("/Home/Login");
            }
        }
    }
}
