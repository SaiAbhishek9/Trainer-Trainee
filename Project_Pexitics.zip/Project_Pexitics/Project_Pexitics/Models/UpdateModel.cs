﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project_Pexitics.Models
{
    public class UpdateModel
    {
        [Required(ErrorMessage ="*")]
        public string TraineeEmail { get; set; }
        [Required(ErrorMessage ="*")]
        public string OldPassword { get; set; }
        [Required(ErrorMessage ="*")]
        public string NewPassword { get; set; }
    }
}
