﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project_Pexitics.Models
{
    [Table("tbl_Projects")]
    public class ProjectModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [Required(ErrorMessage ="*")]
        [StringLength(100,ErrorMessage ="*")]
        public string Name { get; set; }

        [Required(ErrorMessage = "*")]
        [StringLength(100, ErrorMessage = "*")]
        public string Description { get; set; }

        [Required(ErrorMessage = "*")]
        public string Technology { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
         public DateTime AssignDate { get; set; }
        
        [Required(ErrorMessage ="*")]
        [EmailAddress(ErrorMessage ="Invalid Format")]
        public string AddedByEmail { get; set; }

        [ForeignKey("AddedByEmail")]
        public NewTrainerModel Trainer { get; set; }


       

       // public List<AssignModel> AssignTrainees { get; set; }

    }
}
