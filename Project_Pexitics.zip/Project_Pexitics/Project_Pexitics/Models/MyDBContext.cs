﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace Project_Pexitics.Models
{
    public class MyDBContext:DbContext
    {
        public MyDBContext(DbContextOptions<MyDBContext> opt):base(opt)
        {
        }

    /*    public MyDBContext(DbContextOptions<MyDBContext> opt) : base(opt)
        {

        }
*/
        public DbSet<NewTrainerModel> Trainer { get; set; }
        public DbSet<TraineeModel> Trainee { get; set; }
        public DbSet<ProjectModel> Project { get; set; }
        public DbSet<AssignProjectsModel> Assign { get; set; }
      //  public DbSet<ViewModel> View { get; set; }


        //By Using Fluient API
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AssignProjectsModel>().ToTable("tbl_assign");
            modelBuilder.Entity<AssignProjectsModel>().Property(p => p.AssignedDate).HasComputedColumnSql("getdate()");
            modelBuilder.Entity<AssignProjectsModel>().HasKey(a =>new { a.ProjectID,a.TraineeEmail });
          //  modelBuilder.Entity<AssignProjectsModel>().Property(p => p.AssignedDate).IsRequired();

        }

    }
}
