﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project_Pexitics.Models
{
    [Table("tbl_NewTrainee")]
    public class NewTrainerModel
    {
      

        [Required(ErrorMessage ="*")]
        [StringLength(100,ErrorMessage ="Max 100 Chars")]
        public string Name { get; set; }

        [Key]
        [Required(ErrorMessage ="*")]
        [EmailAddress(ErrorMessage ="Invalid Format")]
        public string Email { get; set; }

        [Required(ErrorMessage ="*")]
        [StringLength(10,ErrorMessage ="Max 10 Chars")]
        public string password { get; set; }

        [Required(ErrorMessage ="*")]

        public string City { get; set; }

        public List<TraineeModel> Trainees { get; set; }

        public List<ProjectModel> Projects { get; set; }

    }
}
