﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Pexitics.Models
{
    public class TViewModel
    {
        public int ProjectID { get; set; }
        public string TraineeEmail { get; set; }
        public DateTime AssignedDate { get; set; }
        public string ProjectStatus { get; set; }
    }
}
