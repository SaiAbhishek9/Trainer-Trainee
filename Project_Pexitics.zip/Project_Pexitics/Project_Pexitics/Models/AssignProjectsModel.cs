﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project_Pexitics.Models
{
   // [Table("tbl_Assign")]
    public class AssignProjectsModel
    {
       // [Key,Column(Order =0)]
        public int ProjectID { get; set; }
       // [Key,Column(Order =1)]
        public string TraineeEmail { get; set; }

     //   [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime AssignedDate { get; set; }

        public string ProjectStatus { get; set; }
    }
}
