﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Project_Pexitics.Models
{
    [Table("tbl_Login")]
    public class LoginModel
    {
        [Required(ErrorMessage ="*")]
        [EmailAddress(ErrorMessage ="Invalid Format")]
        public string Email { get; set; }
        
        [Required(ErrorMessage ="*")]
        
        public string Password { get; set; }

        [Required(ErrorMessage ="*")]
        public string LoginType { get; set; }

        public List<SelectListItem> plist { get; } = new List<SelectListItem>{
        new SelectListItem { Text = "Select", Value = "" },
        new SelectListItem { Text = "Trainer", Value = "Trainer" },
        new SelectListItem { Text = "Trainee", Value = "Trainee" }
          };


    }
}
