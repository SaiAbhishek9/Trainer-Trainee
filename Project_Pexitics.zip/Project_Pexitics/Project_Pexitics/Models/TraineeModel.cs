﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project_Pexitics.Models
{
    [Table("tbl_Trainee")]
    public class TraineeModel
    {
       

        [Required(ErrorMessage ="*")]
        [StringLength(100,ErrorMessage ="Max 100 chars")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "*")]
        [StringLength(100, ErrorMessage = "Max 100 chars")]
        public string LastName { get; set; }

        [Key]
        [Required(ErrorMessage ="*")]
        [EmailAddress(ErrorMessage ="Invalid Format")]
        public string Email { get; set; }

        [Required(ErrorMessage = "*")]
        [StringLength(10, ErrorMessage = "Max 100 chars")]
        public string Password { get; set; }

        [Required(ErrorMessage = "*")]
        [StringLength(100, ErrorMessage = "Max 100 chars")]
        public string Qualification { get; set; }

        [Required(ErrorMessage ="*")]
        [EmailAddress(ErrorMessage ="Invalid Format")]
        public string AddedByEmail { get; set; }

        [ForeignKey("AddedByEmail")]
        public NewTrainerModel Trainer { get; set; }


      //  public List<AssignModel> AssignTrainees { get; set; }
    }
}
