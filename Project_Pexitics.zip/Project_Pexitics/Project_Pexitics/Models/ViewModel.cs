﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project_Pexitics.Models
{
    public class ViewModel
    {
        public string TraineeEmail { get; set; }
        public string TraineeName { get; set; }
        public int ProjectID { get; set; }
        public string Status { get; set; }
    }
}
