﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Project_Pexitics.Models;
using Project_Pexitics.Filters;

namespace Project_Pexitics.Controllers
{
    [AuthFilter]

    public class HomeController : Controller
    {

        MyDBContext db;
        public HomeController(MyDBContext db)
        {
            this.db = db;
            
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Index1()
        {
            return View();
        }

    

        public IActionResult Login()
        {
            List<SelectListItem> plist = new List<SelectListItem>();
            plist.Add(new SelectListItem { Text = "Select", Value = "" });
            plist.Add(new SelectListItem { Text = "Trainer", Value = "Trainer" });
            plist.Add(new SelectListItem { Text = "Trainee", Value = "Trainee" });
            ViewBag.plist = plist;
            return View();
        }
        [HttpPost]

        public IActionResult Login(LoginModel model)
        {
            // MyDBContext db = new MyDBContext();

           // HttpContext.Session.SetString("TeEmail", model.Email);
           
            int count = db.Trainer.Count((c) => c.Email == model.Email && c.password == model.Password);
            int count1 = db.Trainee.Count((c) => c.Email == model.Email && c.Password == model.Password);
            if (count > 0)
            {
                if (model.LoginType == "Trainer")
                {
                    HttpContext.Session.SetString("TrEmail", model.Email);

                    return View("Index");
                }
            }
                if (count1 > 0)
                {
                    if (model.LoginType == "Trainee")
                    {
                    HttpContext.Session.SetString("TrEmail", model.Email);
                    return View("Index1");
                    }
                
                else
                {
                    return View();
                }

                }
                else
                {
                    ViewBag.msg = "Invalid Email or Password";
                    return View();
                }
            }
        

        public IActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Home");
        }

        public IActionResult AddTrainer()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddTrainer(NewTrainerModel model)
        {
            // MyDBContext db=new MyDBContext();
            int count = db.Trainer.Count((c) => c.Email == model.Email);
            if (count > 0)
            {
                ViewBag.mail = "Email Already Exists..";
                return View();
            }
            else
            {
                
                db.Trainer.Add(model);
                db.SaveChanges();
                ViewBag.msg = "Trainer Added Successfully.";
                return View();
            }
        }
        public IActionResult AddTrainee()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddTrainee(TraineeModel model)
        {
            // MyDBContext db = new MyDBContext();
             model.AddedByEmail = HttpContext.Session.GetString("TrEmail");
            

            int count = db.Trainee.Count((c) => c.Email == model.Email);
            if (count > 0)
            {
                ViewBag.mail = "Email Already Exists..";
                return View();
            }
            else
            {
                               
                db.Trainee.Add(model);
                db.SaveChanges();
                ViewBag.msg = "Trainee added successfully";
                return View();
            }
        }

        public IActionResult AddProject()
        {
            ProjectModel model = new ProjectModel();
            model.AddedByEmail = HttpContext.Session.GetString("TrEmail");

            List<SelectListItem> plist = new List<SelectListItem>();
            plist.Add(new SelectListItem { Text = "Select", Value = "" });
            plist.Add(new SelectListItem { Text = ".NET", Value = ".NET" });
            plist.Add(new SelectListItem { Text = "Java", Value = "Java" });
            plist.Add(new SelectListItem { Text = "Angular JS", Value = "Angular JS" });

            ViewBag.plist = plist;
            return View();
        }
        [HttpPost]
        public IActionResult AddProject(ProjectModel model)
        {
            // MyDBContext db = new MyDBContext();

            model.AddedByEmail = HttpContext.Session.GetString("TrEmail");

            HttpContext.Session.SetInt32("PID", model.ID);

            db.Project.Add(model);
            db.SaveChanges();
            ViewBag.msg = "Project added..."+ " "+model.ID.ToString();
            return View();
        }

        public IActionResult ViewTrainees()
        {
            string email = HttpContext.Session.GetString("TrEmail");
            List<TraineeModel> trainee = db.Trainee.Where((t) => t.AddedByEmail == email).ToList();
            return View(trainee);
        }
        
        public IActionResult ViewProjects()
        {
            string email = HttpContext.Session.GetString("TrEmail");
            List<ProjectModel> project = db.Project.Where((p) => p.AddedByEmail == email).ToList();
            return View(project);
        }
       
        public IActionResult ViewTraineeProfile()
        {
            string email = HttpContext.Session.GetString("TrEmail");
            List<TraineeModel> trainee = db.Trainee.Where((t) => t.Email == email).ToList();
            return View(trainee);
        }


        public IActionResult AssignProjects(int id)
        {
            var obj1 = db.Project.FirstOrDefault(p => p.ID == id);

            ViewBag.id = obj1.ID;
            ViewBag.name = obj1.Name;


            // plist.Add(new SelectListItem { Text = "Select", Value = "" });
            HttpContext.Session.SetInt32("id", id);
            string email = HttpContext.Session.GetString("TrEmail");
            IEnumerable<SelectListItem> items = db.Trainee.Where(c=>c.AddedByEmail==email).Select((s) => new SelectListItem { Value=s.Email,Text=s.Email});

            ViewBag.items = items;

            return View();

        }

        [HttpPost]
       public IActionResult AssignProjects(AssignProjectsModel model)
        {
            

            string email = HttpContext.Session.GetString("TrEmail");
            IEnumerable<SelectListItem> items = db.Trainee.Where(c => c.AddedByEmail == email).Select((s) => new SelectListItem { Value = s.Email, Text = s.Email });
            ViewBag.items = items;
            

        int PID= Convert.ToInt32(HttpContext.Session.GetInt32("id"));
            int count = db.Assign.Count((a) => a.TraineeEmail == model.TraineeEmail && a.ProjectID==PID);
            if (count==0)
            {
                model.ProjectID = Convert.ToInt32(HttpContext.Session.GetInt32("id"));
                model.ProjectStatus = "Assigned";
                db.Assign.Add(model);
                db.SaveChanges();
                ViewBag.msg = "Assigned Successfully...";
                return View();
            }
            else
            {
                ViewBag.err = "Already Assigned";
                return View();
            }
        }

    public IActionResult Assigned(int id)
        {
            
            var obj = db.Project.FirstOrDefault(p => p.ID == id);
            ViewBag.ID = obj.ID;
            ViewBag.Title = obj.Name;
            
            List<string> traineeids = db.Assign.Where((p) => p.ProjectID==id).Select((s) => s.TraineeEmail).ToList();

            List<ViewModel> assi = db.Assign.Join(db.Trainee,(a)=>a.TraineeEmail,(t)=>t.Email,(a,t)=>new ViewModel
            { ProjectID=a.ProjectID,TraineeEmail=a.TraineeEmail,Status=a.ProjectStatus,TraineeName=t.FirstName+" "+t.LastName }).Where(c=>traineeids.Contains(c.TraineeEmail)).ToList();
                
            return View(assi);
        }
        
        public IActionResult MyAssignedProjects()
        {
            /*
            var obj2 = db.Project.FirstOrDefault(p => p.ID == id);
            ViewBag.Title = obj2.Name;
            ViewBag.Tech = obj2.Technology;
            ViewBag.Desc = obj2.Description;
            */
            
            string email = HttpContext.Session.GetString("TrEmail");
            List<int> Asprjts = db.Assign.Where((a) => a.TraineeEmail == email).Select((s) => s.ProjectID).ToList();

            List<TViewModel> tassi = db.Assign.Join(db.Project, (a) => a.ProjectID, (t) => t.ID, (a, t) => new TViewModel
            { ProjectID = a.ProjectID,TraineeEmail = a.TraineeEmail, AssignedDate = a.AssignedDate, ProjectStatus = a.ProjectStatus }).Where(c => Asprjts.Contains(c.ProjectID) && c.ProjectStatus!="Submitted").ToList();
            return View(tassi);
        }
      
        
        public IActionResult SetStatus(int id)
        {

            string email = HttpContext.Session.GetString("TrEmail");

            List<SelectListItem> plist = new List<SelectListItem>();
            plist.Add(new SelectListItem { Text = "Select", Value = "" });
            plist.Add(new SelectListItem { Text = "Assigned", Value = "Assigned" });
            plist.Add(new SelectListItem { Text = "In-Progress", Value = "In-Progress" });
            plist.Add(new SelectListItem { Text = "Completed", Value = "Completed" });
            plist.Add(new SelectListItem { Text = "Submitted", Value = "Submitted" });
            ViewBag.plist = plist;

            AssignProjectsModel model = db.Assign.FirstOrDefault((a) => a.TraineeEmail == email && a.ProjectID==id);
            return View(model);
        }
        [HttpPost]

        public IActionResult SetStatus(AssignProjectsModel model)
        {
            var modeldb = db.Assign.FirstOrDefault(m => m.ProjectID == model.ProjectID && m.TraineeEmail == model.TraineeEmail);
            modeldb.ProjectStatus = model.ProjectStatus;
            db.SaveChanges();
            // ViewBag.msg = "Status Set Successfull..";
            return RedirectToAction("MyAssignedProjects", "Home");
        }
        
        public IActionResult UpdatePassword()
        {
            string email = HttpContext.Session.GetString("TrEmail");
            TraineeModel model = db.Trainee.FirstOrDefault((t) => t.Email == email);
            return View();
        }

        [HttpPost]
        public IActionResult UpdatePassword(UpdateModel model)
        {
         
            var modeldb = db.Trainee.FirstOrDefault(m => m.Email == model.TraineeEmail && m.Password==model.OldPassword);
            if (modeldb != null)
            {
                modeldb.Password = model.NewPassword;
                db.SaveChanges();
                return RedirectToAction("Login", "Home");
            }
            else
            {
                ViewBag.msg = "Login ID or Password Invalid";
                return View();
            }
        }

    }
}